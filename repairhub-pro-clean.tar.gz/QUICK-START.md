# ⚡ Быстрый старт - Деплой на сервер

## ✅ Статус подготовки:
- ✅ API ключи обновлены
- ✅ Сборка протестирована
- ✅ Документация создана
- ✅ Скрипты готовы

## 🔑 Доступ к серверу:
```
IP: 70.34.252.148
User: root
Pass: {6Aj5ujyYVWYC,-p
```

## 🚀 5 шагов до работающего приложения:

### 1️⃣ Подключение к серверу
```bash
ssh root@70.34.252.148
```

### 2️⃣ Очистка старых проектов
```bash
./server-cleanup.sh
```

### 3️⃣ Загрузка проекта (с локального ПК)
```bash
scp repairhub-pro-server.tar.gz root@70.34.252.148:/tmp/
```

### 4️⃣ Деплой проекта
```bash
cd /opt
tar -xzf /tmp/repairhub-pro-server.tar.gz
cd repairhub-pro
./deploy-to-server.sh
```

### 5️⃣ Проверка работы
```bash
curl http://70.34.252.148
```

## 📁 Готовые файлы:
- `repairhub-pro-server.tar.gz` - проект для загрузки
- `server-cleanup.sh` - очистка Docker
- `deploy-to-server.sh` - автоматический деплой
- `SERVER-DEPLOYMENT-README.md` - полная документация

## 🌐 После деплоя:
- Приложение: http://70.34.252.148
- Статус: `docker-compose ps`
- Логи: `docker-compose logs -f`

**🎉 Всё готово к запуску!**
