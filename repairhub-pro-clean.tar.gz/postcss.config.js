export default {
  plugins: {
    tailwindcss: {},
  },
}

